const mongoose = require('mongoose');
 
//Attributes of the Sales object
var saleSchema = new mongoose.Schema({
manufacturer: {
type: String,
required: 'This field is required!'
},
model: {
type: String
},
salesInThds: {
type: String
},
vehicleType: {
type: String
},
priceInThds: {
type: String
}
});
 
mongoose.model('Sale', saleSchema);