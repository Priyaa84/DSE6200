sales.mapReduce(
    function () {
        emit(1, this.manufacturer)
    },
    function (k, v) {
        var result = {};
        result.manufacturer = v;
        return result;
    },
    { out: { inline: 1 } },
    function (err, result) {
        assert.equal(null, err);

        if (result) {
            console.log(result[0].value.manufacturer);
        }
        db.close();
    }
);