var doMapReduce = function(options, callback) {

    var map = function () {
        emit (this.manufacturer,this.salesInThds);
    };

    var reduce = function (key, values) {
        return Array.sum(values);
    };

    db.sales.mapReduce(map, reduce);
}
