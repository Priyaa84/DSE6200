const mongoose = require('mongoose');
const express = require('express');

var app = express();
const path = require('path');
const bodyparser = require('body-parser');

var Handlebars = require('handlebars')
var exphb = require('express-handlebars');
var {allowInsecurePrototypeAccess} = require('@handlebars/allow-prototype-access')



//Attributes of the Sales object
var saleSchema = new mongoose.Schema({
	Manufacturer: {
	type: String,
	required: 'This field is required!'
	},
	Model: {
	type: String
	},
	Vehicle_Type: {
	type: String
	},
	Resale_Value: {
	type: Number
	},
	Listing_Price: {
	type: Number
	}
	});


module.exports = mongoose.model('Sale', saleSchema);



// Create Schema for Individual Companies

const Sale = mongoose.model('Sale');

const GM_Sales = Sale.aggregate([
                { $match: {Manufacturer: {$in:["Cadillac","Chevrolet", "GMC"]}}}]).exec(function ( e, d ) {console.log( e )});
                
const Stel_Sales = Sale.aggregate([
                { $match: {Manufacturer: {$in:["Chrysler","Dodge", "Jeep"]}}}]).exec(function ( e, d ) {console.log( e )});
    
const Ford_Sales = Sale.aggregate([
				{ $match: {Manufacturer: {$in:["Ford","Lincoln"]}}}]).exec(function ( e, d ) {console.log( e )});

const Other_Sales = Sale.aggregate([
                { $match: {Manufacturer: {$not: {$in:["Chrysler", "Dodge", "Jeep", "Chevrolet", "Cadillac", "Ford", "Lincoln"]}}}}
                ]).exec(function ( e, d ) {console.log( e )});
                
app.get('/example', (req, res) => {
  res.send(GM_Sales);
});




